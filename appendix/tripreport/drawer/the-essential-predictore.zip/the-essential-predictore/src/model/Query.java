package model;

public enum Query {
	QALCULATESTOCK("create table _view_stockcalculations as " +
			"( " +
			"select foo3.sourceid, foo3.reportperiod, foo3.dataelementid, foo3.drugname, foo4.stkeom3 as stockremaining, " +
			"foo3.totalstockrcd, foo4.stockdifference, " +
			"round((foo4.stockdifference+foo3.totalstockrcd)/3) as stkamc, " +
			"round((foo4.stockdifference+foo3.totalstockrcd)/3)* " +
			"case when con2.value <> null then cast(con2.value as numeric) else 2::numeric end - foo4.stkeom3 as resupplyquantity, " +
			"round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2) as monthsofstock, " +
			"case when round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2)< " +
			"case when con.value <> null then cast(con.value as numeric) else 0.75::numeric end " +
			"then 1::int " +
			"when round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2) >" +
			"case when con2.value <> null then cast(con2.value as numeric) else 2::numeric end * 2 " +
			"then 2::int " +
			"else 0::int " +
			"end as stocksituation, " +
			"con.value as emergencylevelmonths, " +
			"con.name as constantname1, " +
			"con2.value as reorderquantitymonths, " +
			"con2.name as constantname2 " +
			"from " +
			"( " +
			"select sourceid, reportperiod, dataelementid, drugname, " +
			"sum(rcd3) as stkrcd3, " +
			"sum(rcd2) as stkrcd2, " +
			"sum(rcd1) as stkrcd1, " +
			"sum(rcd0) as stkrcd0, " +
			"sum(rcd3)+sum(rcd2)+sum(rcd1)+sum(rcd0) as totalstockrcd " +
			"from ( " +
			"SELECT " +
			"dv.sourceid, " +
			"pe.startdate, " +
			"dv.value, " +
			"dv.dataelementid, " +
			"left(de.name,length(de.name)-3) AS drugname, " +
			"de.code as datalementcode, " +
			"'201303'::varchar as reportperiod, " +
			"cast(concat('201303','01') as date) as periodstartdate, " +
			"case when pe.startdate between cast(concat('201303','01') as date)  and " +
			"cast(concat('201303','01') as date) + interval '1 month' - interval '1 day' " +
			"then cast(dv.value as double precision) " +
			"else 0 end as rcd3, " +
			"case when pe.startdate between cast(concat('201303','01') as date) - interval '1 month' and " +
			"cast(concat('201303','01') as date) - interval '1 day' " +
			"then cast(dv.value as double precision) " +
			"else 0 end as rcd2, " +
			"case when pe.startdate between cast(concat('201303','01') as date) - interval '2 month' " +
			"and cast(concat('201303','01') as date) - interval '1 month' - interval '1 day' " +
			"then cast(dv.value as double precision) " +
			"else 0 end as rcd1, " +
			"case when pe.startdate between cast(concat('201303','01') as date) - interval '3 month' " +
			"and cast(concat('201303','01') as date) - interval '2 month' - interval '1 day' " +
			"then cast(dv.value as double precision) " +
			"else 0 end as rcd0 " +
			"FROM " +
			"public.datavalue dv, " +
			"public.dataelement de, " +
			"public.period pe " +
			"WHERE " +
			"dv.dataelementid = de.dataelementid and " +
			"dv.periodid=pe.periodid and " +
			"dv.dataelementid in ( " +
			"select dataelementid from dataelementgroupmembers where dataelementgroupmembers.dataelementgroupid = 18146) and " +
			"pe.startdate between cast(concat('201304'::varchar,'01'::varchar) as date) - interval '4 month' " +
			"and cast(concat('201304'::varchar,'01'::varchar) as date)) as foo " +
			"group by sourceid, reportperiod, drugname, dataelementid) as foo3 " +
			"left join ( " +
			"select sourceid, reportperiod, dataelementid, drugname, datalementcode, " +
			"sum(stk3) as stkeom3, " +
			"sum(stk2) as stkeom2, " +
			"sum(stk1) as stkeom1, " +
			"sum(stk0) as stkeom0, " +
			"sum(stk3)-sum(stk2)+sum(stk2)-sum(stk1)+sum(stk1)-sum(stk0) as stockdifference " +
			"from ( " +
			"SELECT " +
			"dv.sourceid, " +
			"pe.startdate, " +
			"dv.value, " +
			"dv.dataelementid, " +
			"left(de.name,length(de.name)-3) AS drugname, " +
			"de.code as datalementcode, " +
			"'201303'::varchar as reportperiod, " +
			"cast(concat('201303','01') as date) as periodstartdate, " +
			"case when  pe.startdate= cast(concat('201303','01') as date) then cast(dv.value as double precision) " +
			"else 0 end as stk3, " +
			"case when pe.startdate = cast(concat('201303','01') as date) - interval '1 month'  then cast(dv.value as double precision) " +
			"else 0 end as stk2, " +
			"case when pe.startdate = cast(concat('201303','01') as date) - interval '2 month'  then cast(dv.value as double precision) " +
			"else 0 end as stk1, " +
			"case when pe.startdate = cast(concat('201303','01') as date) - interval '3 month'  then cast(dv.value as double precision) " +
			"else 0 end as stk0 " +
			"FROM " +
			"public.datavalue dv, " +
			"public.dataelement de, " +
			"public.period pe " +
			"WHERE " +
			"dv.dataelementid = de.dataelementid and " +
			"dv.periodid=pe.periodid and " +
			"dv.dataelementid in ( " +
			"select dataelementid from dataelementgroupmembers where dataelementgroupmembers.dataelementgroupid = 18144) and " +
			"pe.startdate between cast(concat('201304'::varchar,'01'::varchar) as date) - interval '4 month' " +
			"and cast(concat('201304'::varchar,'01'::varchar) as date)) as foo2 " +
			"group by sourceid, reportperiod, dataelementid, drugname, datalementcode) as foo4 " +
			"on foo3.sourceid=foo4.sourceid and " +
			"foo3.reportperiod=foo4.reportperiod and " +
			"foo3.drugname=foo4.drugname " +
			"left join constant con on con.name = 'EmergencyOrderLevelMonth' " +
			"left join constant con2 on con2.name = 'ReorderQuantityMonth' " +
			"order by sourceid, drugname);"),
	DELETEAMC("delete from datavalue " +
			"where dataelementid in " +
			"(select dataelementid from dataelementgroupmembers dgm " +
			"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
			"where dg.shortname='stockAMC') " +
			"and periodid in " +
			"(select ps.periodid from period pe " +
			"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
			"where iso = '201303');"),
	LOADAMC("insert into datavalue " +
			"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
			"15 as attributeoptioncomboid, " +
			"trim(cast(vs.stkamc as varchar)) as value, " +
			"'hmismobile2016' as storedby, " +
			"current_timestamp as lastupdated, " +
			"'inserted by stock calculation app' as comment " +
			"from _view_stockcalculations vs " +
			"inner join dataelement de on (concat(vs.drugname,'amc')=de.shortname) " +
			"inner join _periodstructure ps on (vs.reportperiod=ps.iso);"),
	DELETERESUPPLYQUANTITY("delete from datavalue " +
			"where dataelementid in " +
			"(select dataelementid from dataelementgroupmembers dgm " +
			"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
			"where dg.shortname='StockREQ') " +
			"and periodid in " +
			"(select ps.periodid from period pe " +
			"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
			"where iso = '201303');"),
	LOADRESUPPLYQUANTITY("insert into datavalue " +
			"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
			"15 as attributeoptioncomboid, " +
			"trim(cast(vs.resupplyquantity as varchar)) as value, " +
			"'hmismobile2016' as storedby, " +
			"current_timestamp as lastupdated, " +
			"'inserted by stock calculation app' as comment " +
			"from _view_stockcalculations vs " +
			"inner join dataelement de on (concat(vs.drugname,'req')=de.shortname) " +
			"inner join _periodstructure ps on (vs.reportperiod=ps.iso);"),
	DELETESTOCKSITUATION("delete from datavalue " +
			"where dataelementid in " +
			"(select dataelementid from dataelementgroupmembers dgm " +
			"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
			"where dg.shortname='StockEmergency') " +
			"and periodid in " +
			"(select ps.periodid from period pe " +
			"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
			"where iso = '201303');"),
	LOADSTOCKSITUATION("insert into datavalue " +
			"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
			"15 as attributeoptioncomboid, " +
			"trim(cast(vs.stocksituation as varchar)) as value, " +
			"'hmismobile2016' as storedby, " +
			"current_timestamp as lastupdated, " +
			"'inserted by stock calculation app' as comment " +
			"from _view_stockcalculations vs " +
			"inner join dataelement de on (concat(vs.drugname,'emr')=de.shortname) " +
			"inner join _periodstructure ps on (vs.reportperiod=ps.iso);"),
	DROPSTOCKCALCULATIONS("drop table if exists _view_stockcalculations;"),
	SETOWNERTOSTOCKCALCULATIONS("alter table _view_stockcalculations owner to hmismobile2016;");
	
	private String queryAsString;
	
	private Query(String queryAsString){
		this.queryAsString = queryAsString;
		
	}
	
	public String getQueryAsString(){
		return this.queryAsString;
	}
	public static String makeQalculateStockString(String reportPeriod){
		return "create table _view_stockcalculations as " +
				"( " +
				"select foo3.sourceid, foo3.reportperiod, foo3.dataelementid, foo3.drugname, foo4.stkeom3 as stockremaining, " +
				"foo3.totalstockrcd, foo4.stockdifference, " +
				"round((foo4.stockdifference+foo3.totalstockrcd)/3) as stkamc, " +
				"round((foo4.stockdifference+foo3.totalstockrcd)/3)* " +
				"case when con2.value <> null then cast(con2.value as numeric) else 2::numeric end - foo4.stkeom3 as resupplyquantity, " +
				"round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2) as monthsofstock, " +
				"case when round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2)< " +
				"case when con.value <> null then cast(con.value as numeric) else 0.75::numeric end " +
				"then 1::int " +
				"when round(cast(foo4.stkeom3/round((foo4.stockdifference+foo3.totalstockrcd)/3) as numeric),2) >" +
				"case when con2.value <> null then cast(con2.value as numeric) else 2::numeric end * 2 " +
				"then 2::int " +
				"else 0::int " +
				"end as stocksituation, " +
				"con.value as emergencylevelmonths, " +
				"con.name as constantname1, " +
				"con2.value as reorderquantitymonths, " +
				"con2.name as constantname2 " +
				"from " +
				"( " +
				"select sourceid, reportperiod, dataelementid, drugname, " +
				"sum(rcd3) as stkrcd3, " +
				"sum(rcd2) as stkrcd2, " +
				"sum(rcd1) as stkrcd1, " +
				"sum(rcd0) as stkrcd0, " +
				"sum(rcd3)+sum(rcd2)+sum(rcd1)+sum(rcd0) as totalstockrcd " +
				"from ( " +
				"SELECT " +
				"dv.sourceid, " +
				"pe.startdate, " +
				"dv.value, " +
				"dv.dataelementid, " +
				"left(de.name,length(de.name)-3) AS drugname, " +
				"de.code as datalementcode, " +
				"'"+reportPeriod+"'::varchar as reportperiod, " +
				"cast(concat('"+reportPeriod+"','01') as date) as periodstartdate, " +
				"case when pe.startdate between cast(concat('"+reportPeriod+"','01') as date)  and " +
				"cast(concat('"+reportPeriod+"','01') as date) + interval '1 month' - interval '1 day' " +
				"then cast(dv.value as double precision) " +
				"else 0 end as rcd3, " +
				"case when pe.startdate between cast(concat('"+reportPeriod+"','01') as date) - interval '1 month' and " +
				"cast(concat('"+reportPeriod+"','01') as date) - interval '1 day' " +
				"then cast(dv.value as double precision) " +
				"else 0 end as rcd2, " +
				"case when pe.startdate between cast(concat('"+reportPeriod+"','01') as date) - interval '2 month' " +
				"and cast(concat('"+reportPeriod+"','01') as date) - interval '1 month' - interval '1 day' " +
				"then cast(dv.value as double precision) " +
				"else 0 end as rcd1, " +
				"case when pe.startdate between cast(concat('"+reportPeriod+"','01') as date) - interval '3 month' " +
				"and cast(concat('"+reportPeriod+"','01') as date) - interval '2 month' - interval '1 day' " +
				"then cast(dv.value as double precision) " +
				"else 0 end as rcd0 " +
				"FROM " +
				"public.datavalue dv, " +
				"public.dataelement de, " +
				"public.period pe " +
				"WHERE " +
				"dv.dataelementid = de.dataelementid and " +
				"dv.periodid=pe.periodid and " +
				"dv.dataelementid in ( " +
				"select dataelementid from dataelementgroupmembers where dataelementgroupmembers.dataelementgroupid = 18146) and " +
				"pe.startdate between cast(concat('201304'::varchar,'01'::varchar) as date) - interval '4 month' " +
				"and cast(concat('201304'::varchar,'01'::varchar) as date)) as foo " +
				"group by sourceid, reportperiod, drugname, dataelementid) as foo3 " +
				"left join ( " +
				"select sourceid, reportperiod, dataelementid, drugname, datalementcode, " +
				"sum(stk3) as stkeom3, " +
				"sum(stk2) as stkeom2, " +
				"sum(stk1) as stkeom1, " +
				"sum(stk0) as stkeom0, " +
				"sum(stk3)-sum(stk2)+sum(stk2)-sum(stk1)+sum(stk1)-sum(stk0) as stockdifference " +
				"from ( " +
				"SELECT " +
				"dv.sourceid, " +
				"pe.startdate, " +
				"dv.value, " +
				"dv.dataelementid, " +
				"left(de.name,length(de.name)-3) AS drugname, " +
				"de.code as datalementcode, " +
				"'"+reportPeriod+"'::varchar as reportperiod, " +
				"cast(concat('"+reportPeriod+"','01') as date) as periodstartdate, " +
				"case when  pe.startdate= cast(concat('"+reportPeriod+"','01') as date) then cast(dv.value as double precision) " +
				"else 0 end as stk3, " +
				"case when pe.startdate = cast(concat('"+reportPeriod+"','01') as date) - interval '1 month'  then cast(dv.value as double precision) " +
				"else 0 end as stk2, " +
				"case when pe.startdate = cast(concat('"+reportPeriod+"','01') as date) - interval '2 month'  then cast(dv.value as double precision) " +
				"else 0 end as stk1, " +
				"case when pe.startdate = cast(concat('"+reportPeriod+"','01') as date) - interval '3 month'  then cast(dv.value as double precision) " +
				"else 0 end as stk0 " +
				"FROM " +
				"public.datavalue dv, " +
				"public.dataelement de, " +
				"public.period pe " +
				"WHERE " +
				"dv.dataelementid = de.dataelementid and " +
				"dv.periodid=pe.periodid and " +
				"dv.dataelementid in ( " +
				"select dataelementid from dataelementgroupmembers where dataelementgroupmembers.dataelementgroupid = 18144) and " +
				"pe.startdate between cast(concat('201304'::varchar,'01'::varchar) as date) - interval '4 month' " +
				"and cast(concat('201304'::varchar,'01'::varchar) as date)) as foo2 " +
				"group by sourceid, reportperiod, dataelementid, drugname, datalementcode) as foo4 " +
				"on foo3.sourceid=foo4.sourceid and " +
				"foo3.reportperiod=foo4.reportperiod and " +
				"foo3.drugname=foo4.drugname " +
				"left join constant con on con.name = 'EmergencyOrderLevelMonth' " +
				"left join constant con2 on con2.name = 'ReorderQuantityMonth' " +
				"order by sourceid, drugname);";
		
	}
	public static String makeDeleteAmcString(String reportPeriod){
		return "delete from datavalue " +
				"where dataelementid in " +
				"(select dataelementid from dataelementgroupmembers dgm " +
				"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
				"where dg.shortname='stockAMC') " +
				"and periodid in " +
				"(select ps.periodid from period pe " +
				"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
				"where iso = '"+reportPeriod+"');";
	}
	public static String makeLoadAmcString(String reportPeriod){
		return "insert into datavalue " +
				"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
				"15 as attributeoptioncomboid, " +
				"trim(cast(vs.stkamc as varchar)) as value, " +
				"'hmismobile2016' as storedby, " +
				"current_timestamp as lastupdated, " +
				"'inserted by stock calculation app' as comment " +
				"from _view_stockcalculations vs " +
				"inner join dataelement de on (concat(vs.drugname,'amc')=de.shortname) " +
				"inner join _periodstructure ps on (vs.reportperiod=ps.iso);";
		
	}
	public static String makeDeleteResupplyString(String reportPeriod){
		return "delete from datavalue " +
				"where dataelementid in " +
				"(select dataelementid from dataelementgroupmembers dgm " +
				"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
				"where dg.shortname='StockREQ') " +
				"and periodid in " +
				"(select ps.periodid from period pe " +
				"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
				"where iso = '"+reportPeriod+"');";
	}
	public static String makeLoadResupplyString(String reportPeriod){
		return "insert into datavalue " +
				"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
				"15 as attributeoptioncomboid, " +
				"trim(cast(vs.resupplyquantity as varchar)) as value, " +
				"'hmismobile2016' as storedby, " +
				"current_timestamp as lastupdated, " +
				"'inserted by stock calculation app' as comment " +
				"from _view_stockcalculations vs " +
				"inner join dataelement de on (concat(vs.drugname,'req')=de.shortname) " +
				"inner join _periodstructure ps on (vs.reportperiod=ps.iso);";
		
	}
	public static String makeDeleteStockSituationString(String reportPeriod){
		return "delete from datavalue " +
				"where dataelementid in " +
				"(select dataelementid from dataelementgroupmembers dgm " +
				"inner join dataelementgroup dg on dgm.dataelementgroupid=dg.dataelementgroupid " +
				"where dg.shortname='StockEmergency') " +
				"and periodid in " +
				"(select ps.periodid from period pe " +
				"inner join _periodstructure ps on (pe.periodid=ps.periodid) " +
				"where iso = '"+reportPeriod+"');";
		
	}
	public static String makeLoadStockSituationString(String reportPeriod){
		return "insert into datavalue " +
				"select de.dataelementid,ps.periodid,vs.sourceid, 15 as categoryoptioncomboid, " +
				"15 as attributeoptioncomboid, " +
				"trim(cast(vs.stocksituation as varchar)) as value, " +
				"'hmismobile2016' as storedby, " +
				"current_timestamp as lastupdated, " +
				"'inserted by stock calculation app' as comment " +
				"from _view_stockcalculations vs " +
				"inner join dataelement de on (concat(vs.drugname,'emr')=de.shortname) " +
				"inner join _periodstructure ps on (vs.reportperiod=ps.iso);";
	}

}
