package model;

public enum DatabaseType {
	POSTGRESQL("Postgres");
	
	private String stringRep;
	
	private DatabaseType(String string){
		stringRep = string;
	}
	
	public String toString(){
		return stringRep;
	}
	
}