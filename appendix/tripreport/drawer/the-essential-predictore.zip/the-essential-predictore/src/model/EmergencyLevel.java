package model;

public class EmergencyLevel extends Level{
	public EmergencyLevel(double value){
		super(value);
	}
}
