package model;

public class ReorderLevel extends Level{
	public ReorderLevel(double value){
		super(value);
	}
}
