package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	
	private DatabaseType type;
	private String adress;
	private int port;
	private String name;
	private String username;
	private String password;
	
	private String calculateStock;
	private String loadAMC;
	private String loadResupplyQuantity;
	private String loadStockSituation;
	
	private Connection connection;
	
	public Database(DatabaseType type, String adress, int port, String name, String username, String password){
		this.type = type;
		this.adress = adress;
		this.port = port;
		this.name = name;
		this.username = username;
		this.password = password;
	}
	
	public void connect(){
		try {
			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection(getConnectionString(), username, password);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
		}
	}
	
	public void close(){
		try {
			this.connection.close();
		} catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public ResultSet executeQuery(String query){
		ResultSet resultSet = null;
		try{
			Statement statement = connection.createStatement();
			resultSet = statement.executeQuery(query);
			
		} catch(SQLException e){
			e.printStackTrace();
		}
		return resultSet;
	}
	
	public void executeUpdate(String sqlString){
		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate(sqlString);
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String getConnectionString(){
		switch(type){
		case POSTGRESQL: default:
			return "jdbc:postgresql://"+adress+":"+port+"/"+name;
		}
	}
	
	public static void main(String[] args){
		Database database = new Database(DatabaseType.POSTGRESQL, "localhost", 5432, "hmismob", "postgres", "Kenzys17");
		database.connect();
		database.executeUpdate(Query.DROPSTOCKCALCULATIONS.getQueryAsString());
		database.executeUpdate(Query.makeQalculateStockString("201303"));
		database.executeUpdate(Query.SETOWNERTOSTOCKCALCULATIONS.getQueryAsString());
		database.executeUpdate(Query.makeDeleteAmcString("201303"));
		database.executeUpdate(Query.makeLoadAmcString("201303"));
		database.executeUpdate(Query.makeDeleteResupplyString("201303"));
		database.executeUpdate(Query.makeLoadResupplyString("201303"));
		database.executeUpdate(Query.makeDeleteStockSituationString("201303"));
		database.executeUpdate(Query.makeLoadStockSituationString("201303"));
		
		/*
		database.executeUpdate(Query.DROPSTOCKCALCULATIONS.getQueryAsString());
		database.executeUpdate(Query.QALCULATESTOCK.getQueryAsString());
		database.executeUpdate(Query.SETOWNERTOSTOCKCALCULATIONS.getQueryAsString());
		database.executeUpdate(Query.DELETEAMC.getQueryAsString());
		database.executeUpdate(Query.LOADAMC.getQueryAsString());
		database.executeUpdate(Query.DELETERESUPPLYQUANTITY.getQueryAsString());
		database.executeUpdate(Query.LOADRESUPPLYQUANTITY.getQueryAsString());
		database.executeUpdate(Query.DELETESTOCKSITUATION.getQueryAsString());
		database.executeUpdate(Query.LOADSTOCKSITUATION.getQueryAsString());
		*/
		
	}
}
