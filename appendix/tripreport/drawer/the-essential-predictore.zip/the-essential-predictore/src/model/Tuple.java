package model;

public class Tuple<Object1, Object2> {
	public final Object1 one;
	public final Object2 two;
	
	public Tuple(Object1 one, Object2 two){
		this.one = one;
		this.two = two;
	}
}
