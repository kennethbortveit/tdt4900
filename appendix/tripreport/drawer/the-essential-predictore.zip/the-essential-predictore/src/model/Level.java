package model;

public class Level {
	private double value;
	
	public Level(double value){
		this.value = value;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
}
