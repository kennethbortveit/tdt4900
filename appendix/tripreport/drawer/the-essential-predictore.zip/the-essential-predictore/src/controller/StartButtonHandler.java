package controller;

import gui.StartScreen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Database;

public class StartButtonHandler implements ActionListener{
	
	private StartScreen startScreen;
	private Database database;
	
	public StartButtonHandler(StartScreen startScreen){
		this.startScreen = startScreen;
		
	}
	
	public void actionPerformed(ActionEvent e){
		
	}
}
