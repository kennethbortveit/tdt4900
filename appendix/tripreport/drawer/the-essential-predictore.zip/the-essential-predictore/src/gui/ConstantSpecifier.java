package gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ConstantSpecifier extends JPanel{
	
	private GridBagLayout layout;
	private JLabel emergencyLabel;
	private GridBagConstraints emergencyLabelConstraints;
	private JTextField emergencyTextField;
	private GridBagConstraints emergencyTextFieldConstraints;
	private JLabel reorderLabel;
	private GridBagConstraints reorderLabelConstraints;
	private JTextField reorderTextField;
	private GridBagConstraints reorderTextFieldConstraints;
	
	
	public ConstantSpecifier(){
		layout = new GridBagLayout();
		setLayout(layout);
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setBackground(Color.WHITE);
		
		emergencyLabel = new JLabel("Emergency Level:");
		emergencyLabelConstraints = new GridBagConstraints();
		emergencyLabelConstraints.gridx = 0;
		emergencyLabelConstraints.gridy = 0;
		emergencyLabelConstraints.anchor = GridBagConstraints.WEST;
		add(emergencyLabel, emergencyLabelConstraints);
		
		emergencyTextField = new JTextField(5);
		emergencyTextFieldConstraints = new GridBagConstraints();
		emergencyTextFieldConstraints.gridx = 1;
		emergencyTextFieldConstraints.gridy = 0;
		emergencyTextFieldConstraints.anchor = GridBagConstraints.WEST;
		add(emergencyTextField, emergencyTextFieldConstraints);
		
		
		
		reorderLabel = new JLabel("Reorder Level:");
		reorderLabelConstraints = new GridBagConstraints();
		reorderLabelConstraints.gridx = 0;
		reorderLabelConstraints.gridy = 1;
		reorderLabelConstraints.anchor = GridBagConstraints.WEST;
		add(reorderLabel, reorderLabelConstraints);
		
		reorderTextField = new JTextField(5);
		reorderTextFieldConstraints = new GridBagConstraints();
		reorderTextFieldConstraints.gridx = 1;
		reorderTextFieldConstraints.gridy = 1;
		reorderTextFieldConstraints.anchor = GridBagConstraints.WEST;
		add(reorderTextField, reorderTextFieldConstraints);
	}
	
	public static void main(String[] args){
		
	}
}
