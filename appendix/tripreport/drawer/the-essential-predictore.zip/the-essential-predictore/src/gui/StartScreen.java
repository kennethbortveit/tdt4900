package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import controller.StartButtonHandler;

public class StartScreen extends JFrame{
	
	private GridBagLayout layout;
	private DatabaseSelector databaseSelector;
	private GridBagConstraints databaseSelectorConstraints;
	private PeriodSelector periodSelector;
	private GridBagConstraints periodSelectorConstraints;
	private ConstantSpecifier constantSpecifier;
	private GridBagConstraints constantSpecifierConstraints;
	private Feedbacker feedbacker;
	private GridBagConstraints feedbackerConstraints;
	private JButton startButton;
	private GridBagConstraints startButtonConstraints;
	
	public StartScreen(String title){
		setTitle(title);
		layout = new GridBagLayout();
		setLayout(layout);
		
		databaseSelector = new DatabaseSelector();
		databaseSelectorConstraints = new GridBagConstraints();
		databaseSelectorConstraints.gridx = 0;
		databaseSelectorConstraints.gridwidth = 2;
		databaseSelectorConstraints.ipadx = 20;
		databaseSelectorConstraints.gridy = 0;
		databaseSelectorConstraints.ipady = 20;
		databaseSelectorConstraints.fill = GridBagConstraints.HORIZONTAL;
		databaseSelectorConstraints.anchor = GridBagConstraints.CENTER;
		add(databaseSelector, databaseSelectorConstraints);
		
		periodSelector = new PeriodSelector();
		periodSelectorConstraints = new GridBagConstraints();
		periodSelectorConstraints.gridx = 0;
		periodSelectorConstraints.ipadx = 20;
		periodSelectorConstraints.weightx = 1;
		periodSelectorConstraints.gridy = 1;
		periodSelectorConstraints.ipady = 20;
		periodSelectorConstraints.weighty = 1;
		periodSelectorConstraints.fill = GridBagConstraints.BOTH;
		periodSelectorConstraints.anchor = GridBagConstraints.WEST;
		add(periodSelector, periodSelectorConstraints);
		
		constantSpecifier = new ConstantSpecifier();
		constantSpecifierConstraints = new GridBagConstraints();
		constantSpecifierConstraints.gridx = 1;
		constantSpecifierConstraints.ipadx = 20;
		constantSpecifierConstraints.weightx = 1;
		constantSpecifierConstraints.gridy = 1;
		constantSpecifierConstraints.ipady = 20;
		constantSpecifierConstraints.weighty = 1;
		constantSpecifierConstraints.fill = GridBagConstraints.BOTH;
		constantSpecifierConstraints.anchor = GridBagConstraints.WEST;
		add(constantSpecifier, constantSpecifierConstraints);
		
		feedbacker = new Feedbacker();
		feedbackerConstraints = new GridBagConstraints();
		feedbackerConstraints.gridx = 0;
		feedbackerConstraints.gridwidth = 2;
		feedbackerConstraints.fill = GridBagConstraints.HORIZONTAL;
		feedbackerConstraints.gridy = 2;
		feedbackerConstraints.anchor = GridBagConstraints.CENTER;
		add(feedbacker, feedbackerConstraints);
		
		startButton = new JButton("Start");
		startButton.addActionListener(new StartButtonHandler(this));
		startButtonConstraints = new GridBagConstraints();
		startButtonConstraints.gridx = 0;
		startButtonConstraints.gridwidth = 2;
		startButtonConstraints.gridy = 3;
		startButtonConstraints.anchor = GridBagConstraints.CENTER;
		add(startButton, startButtonConstraints);
		
		
		
	}
	
	public static void main(String[] args){
		StartScreen ss = new StartScreen("The Essential Predictore");
		ss.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ss.pack();
		ss.setVisible(true);
	}
	
	
}
