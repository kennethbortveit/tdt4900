package gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JPanel;

import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;

public class PeriodSelector extends JPanel{
	
	private enum Month{
		JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
	}
	
	private GridBagLayout layout;
	private UtilDateModel model;
	private JDatePanelImpl datePanel;
	private JDatePickerImpl datePicker;
	private GridBagConstraints datePickerConstraints;
	
	
	public PeriodSelector(){
		layout = new GridBagLayout();
		setLayout(layout);
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setBackground(Color.WHITE);
		
		model = new UtilDateModel();
		datePanel = new JDatePanelImpl(model);
		datePicker = new JDatePickerImpl(datePanel);
		datePickerConstraints = new GridBagConstraints();
		datePickerConstraints.gridx = 2;
		datePickerConstraints.gridy = 1;
		datePickerConstraints.anchor = GridBagConstraints.CENTER;
		add(datePicker, datePickerConstraints);
		
	}

	public int getMonth(){
		return model.getMonth();
	}
	
	public int getYear(){
		return model.getYear();
	}
	public static void main(String[] args){
		PeriodSelector ps = new PeriodSelector();
		
	}

}
