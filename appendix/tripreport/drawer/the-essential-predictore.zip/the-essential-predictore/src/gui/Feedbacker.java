package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Feedbacker extends JPanel{
	
	private GridBagLayout layout;

	private JTextArea textArea;
	private GridBagConstraints textAreaConstraints;
	private JScrollPane scroll;
	private GridBagConstraints scrollConstraints;
	
	public Feedbacker(){
		layout = new GridBagLayout();
		setLayout(layout);
		
		textArea = new JTextArea();
		textArea.setColumns(30);
		textArea.setRows(10);
		scroll = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollConstraints = new GridBagConstraints();
		scrollConstraints.gridx = 0;
		scrollConstraints.gridy = 0;
		add(scroll, scrollConstraints);
	}
	
	public static void main(String[] args){
		
	}
}
