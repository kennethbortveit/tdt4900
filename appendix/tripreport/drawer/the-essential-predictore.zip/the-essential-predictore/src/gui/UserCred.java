package gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class UserCred extends JPanel{
	
	private GridBagLayout layout;
	
	private JLabel usernameLabel;
	private GridBagConstraints usernameLabelConstraints;
	private JTextField username;
	private GridBagConstraints usernameConstraints;
	private JLabel passwordLabel;
	private GridBagConstraints passwordLabelConstraints;
	private JPasswordField password;
	private GridBagConstraints passwordConstraints;
	
	public UserCred(){
		layout = new GridBagLayout();
		setLayout(layout);
		setBackground(Color.WHITE);
		
		usernameLabel = new JLabel("Username");
		usernameLabelConstraints = new GridBagConstraints();
		usernameLabelConstraints.gridx = 0;
		usernameLabelConstraints.gridy = 0;
		usernameLabelConstraints.anchor = GridBagConstraints.WEST;
		add(usernameLabel, usernameLabelConstraints);
		
		username = new JTextField(20);
		usernameConstraints = new GridBagConstraints();
		usernameConstraints.gridx = 1;
		usernameConstraints.gridy = 0;
		usernameConstraints.anchor = GridBagConstraints.WEST;
		add(username, usernameConstraints);
		
		passwordLabel = new JLabel("Password");
		passwordLabelConstraints = new GridBagConstraints();
		passwordLabelConstraints.gridx = 3;
		passwordLabelConstraints.gridy = 0;
		passwordLabelConstraints.anchor = GridBagConstraints.EAST;
		add(passwordLabel, passwordLabelConstraints);
		
		password = new JPasswordField(20);
		passwordConstraints = new GridBagConstraints();
		passwordConstraints.gridx = 2;
		passwordConstraints.gridy = 0;
		passwordConstraints.anchor = GridBagConstraints.EAST;
		add(password, passwordConstraints);
		
	}
}
