package gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.DatabaseType;

public class DatabaseSelector extends JPanel{
	
	private GridBagLayout layout;
	
	private JLabel databaseTypeLabel;
	private GridBagConstraints databaseTypeLabelConstraints;
	private JComboBox<DatabaseType> databaseTypes;
	private GridBagConstraints databaseTypeConstraints;
	private JLabel adressLabel;
	private GridBagConstraints adressLabelConstraints;
	private JTextField adress;
	private GridBagConstraints adressConstraints;
	private JLabel portLabel;
	private GridBagConstraints portLabelConstraints;
	private JTextField port;
	private GridBagConstraints portConstraints;
	private UserCred userCred;
	private GridBagConstraints userCredConstraints;
	
	public DatabaseSelector(){
		
		layout = new GridBagLayout();
		setLayout(layout);
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setBackground(Color.WHITE);
		
		databaseTypeLabel = new JLabel("DB Type:");
		databaseTypeLabelConstraints = new GridBagConstraints();
		databaseTypeLabelConstraints.gridx = 0;
		databaseTypeLabelConstraints.gridy = 0;
		add(databaseTypeLabel, databaseTypeLabelConstraints);
		
		databaseTypes = new JComboBox<DatabaseType>();
		addDefaultDBTypes();
		databaseTypeConstraints = new GridBagConstraints();
		databaseTypeConstraints.gridx = 1;
		databaseTypeConstraints.gridy = 0;
		add(databaseTypes, databaseTypeConstraints);
		
		adressLabel = new JLabel("Adress:");
		adressLabelConstraints = new GridBagConstraints();
		adressLabelConstraints.gridx = 2;
		adressLabelConstraints.gridy = 0;
		add(adressLabel, adressLabelConstraints);
		
		adress = new JTextField(20);
		adressConstraints = new GridBagConstraints();
		adressConstraints.gridx = 3;
		adressConstraints.gridy = 0;
		add(adress, adressConstraints);
		
		portLabel = new JLabel("Port:");
		portLabelConstraints = new GridBagConstraints();
		portLabelConstraints.gridx = 4;
		portLabelConstraints.gridy = 0;
		add(portLabel, portLabelConstraints);
		
		port = new JTextField(6);
		portConstraints = new GridBagConstraints();
		portConstraints.gridx = 5;
		portConstraints.gridy = 0;
		add(port, portConstraints);
		
		userCred = new UserCred();
		userCredConstraints = new GridBagConstraints();
		userCredConstraints.gridx = 0;
		userCredConstraints.gridy = 1;
		userCredConstraints.gridwidth = 6;
		userCredConstraints.anchor = GridBagConstraints.CENTER;
		add(userCred, userCredConstraints);
		
		
	}
	
	private void addDefaultDBTypes(){
		databaseTypes.addItem(DatabaseType.POSTGRESQL);
	}
	
	public HashMap<String, String> getDatabaseInfo(){
		HashMap<String, String> databaseInfo = new HashMap<String, String>();
		databaseInfo.put("databaseType", this.databaseTypes.getSelectedItem().toString());
		return databaseInfo;
	}
	
	public static void main(String[] args){
		
	}
}
